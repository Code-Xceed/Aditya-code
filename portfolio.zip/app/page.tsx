"use client"

import React from 'react';
import App from '../src/App';

export default function SyntheticV0PageForDeployment() {
  return <App />;
}

