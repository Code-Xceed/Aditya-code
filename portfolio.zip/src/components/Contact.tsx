import React, { useState, useRef } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { Send } from 'lucide-react';
import Popup from './Popup';

export default function Contact() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showPopup, setShowPopup] = useState(false);

  const formRef = useRef<HTMLDivElement>(null);

  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const rotateX = useTransform(y, [-100, 100], [5, -5]);
  const rotateY = useTransform(x, [-100, 100], [-5, 5]);

  const springConfig = { damping: 15, stiffness: 300 };
  const rotateXSpring = useSpring(rotateX, springConfig);
  const rotateYSpring = useSpring(rotateY, springConfig);

  function handleMouse(event: React.PointerEvent<HTMLDivElement>) {
    const rect = formRef.current?.getBoundingClientRect();

    if (rect) {
      const width = rect.width;
      const height = rect.height;

      const mouseX = event.clientX - rect.left;
      const mouseY = event.clientY - rect.top;

      const xPct = (mouseX / width - 0.5) * 2;
      const yPct = (mouseY / height - 0.5) * 2;

      x.set(xPct * 100);
      y.set(yPct * 100);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulating an API call
    await new Promise(resolve => setTimeout(resolve, 2000));

    setIsSubmitting(false);
    setIsSubmitted(true);
    setName('');
    setEmail('');
    setMessage('');

    // Show popup instead of resetting submitted state
    setShowPopup(true);
  }

  return (
    <section id="contact" className="py-20 bg-zinc-900">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">Get in Touch</h2>
        <div className="flex justify-center">
          <motion.div
            ref={formRef}
            onPointerMove={handleMouse}
            onPointerLeave={() => {
              x.set(0);
              y.set(0);
            }}
            style={{
              rotateX: rotateXSpring,
              rotateY: rotateYSpring,
              transformStyle: "preserve-3d",
            }}
            className="w-full max-w-md bg-zinc-800 p-8 rounded-lg shadow-lg perspective-1000"
            whileHover={{
              scale: 1.05,
              boxShadow: "0px 10px 20px rgba(0, 0, 0, 0.4)",
              transition: { duration: 0.3 }
            }}
          >
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-zinc-400 mb-2">Name</label>
                <input
                  type="text"
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-emerald-400"
                  required
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-zinc-400 mb-2">Email</label>
                <input
                  type="email"
                  id="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-emerald-400"
                  required
                />
              </div>
              <div>
                <label htmlFor="message" className="block text-zinc-400 mb-2">Message</label>
                <textarea
                  id="message"
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full bg-zinc-700 rounded px-3 py-2 text-white focus:outline-none focus:ring-2 focus:ring-emerald-400"
                  required
                ></textarea>
              </div>
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-emerald-500 text-white py-2 rounded hover:bg-emerald-600 transition-colors flex items-center justify-center"
              >
                {isSubmitting ? (
                  <motion.div
                    className="h-5 w-5 border-t-2 border-r-2 border-white rounded-full"
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                  />
                ) : (
                  <>
                    Send Message
                    <Send className="ml-2 h-4 w-4" />
                  </>
                )}
              </button>
            </form>
          </motion.div>
        </div>
      </div>
      <Popup
        isOpen={showPopup}
        onClose={() => setShowPopup(false)}
        variant="contact"
      >
        <div className="text-white">
          <h3 className="text-2xl font-bold mb-4">Thank You!</h3>
          <p>Your message has been sent successfully. I'll get back to you as soon as possible.</p>
        </div>
      </Popup>
    </section>
  );
}

