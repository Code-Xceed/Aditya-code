import React from 'react';
import { Link } from 'react-router-dom';

export default function Header() {
  return (
    <header className="bg-zinc-800 text-white py-4">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold">Portfolio</Link>
        <nav>
          <ul className="flex space-x-4">
            <li><Link to="/" className="hover:text-emerald-400">Home</Link></li>
            <li><Link to="#timeline" className="hover:text-emerald-400">Timeline</Link></li>
            <li><Link to="#services" className="hover:text-emerald-400">Services</Link></li>
            <li><Link to="#contact" className="hover:text-emerald-400">Contact</Link></li>
          </ul>
        </nav>
      </div>
    </header>
  );
}

