import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface PopupProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  variant: 'timeline' | 'services' | 'contact';
}

const variants = {
  timeline: {
    background: 'bg-blue-900',
    animation: {
      initial: { scale: 0, rotate: -180 },
      animate: { scale: 1, rotate: 0 },
      exit: { scale: 0, rotate: 180 },
    },
  },
  services: {
    background: 'bg-green-900',
    animation: {
      initial: { y: '-100%', opacity: 0 },
      animate: { y: 0, opacity: 1 },
      exit: { y: '100%', opacity: 0 },
    },
  },
  contact: {
    background: 'bg-purple-900',
    animation: {
      initial: { x: '100%', opacity: 0 },
      animate: { x: 0, opacity: 1 },
      exit: { x: '-100%', opacity: 0 },
    },
  },
};

export default function Popup({ isOpen, onClose, children, variant }: PopupProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className={`relative w-full max-w-md p-6 rounded-lg shadow-xl ${variants[variant].background}`}
            variants={variants[variant].animation}
            initial="initial"
            animate="animate"
            exit="exit"
          >
            <button
              onClick={onClose}
              className="absolute top-2 right-2 text-white hover:text-gray-300"
              aria-label="Close popup"
            >
              ✕
            </button>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

