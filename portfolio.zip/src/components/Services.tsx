import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Popup from './Popup';

const services = [
  { 
    title: 'Web Development', 
    description: 'Creating modern and responsive websites using the latest technologies.',
    details: 'Specializing in React, Next.js, and Node.js to build scalable and performant web applications. Experienced in both frontend and backend development, ensuring seamless integration and optimal user experiences.'
  },
  { 
    title: 'Mobile Apps', 
    description: 'Developing cross-platform mobile applications for iOS and Android.',
    details: 'Utilizing React Native and Flutter to create native-like mobile experiences. Proficient in integrating with device features, optimizing for performance, and ensuring consistent user interfaces across platforms.'
  },
  { 
    title: 'UI/UX Design', 
    description: 'Designing intuitive and beautiful user interfaces and experiences.',
    details: 'Combining aesthetics with functionality to create visually appealing and user-friendly designs. Skilled in using tools like Figma and Adobe XD, and applying design thinking principles to solve complex user problems.'
  },
];

export default function Services() {
  const [selectedService, setSelectedService] = useState<number | null>(null);

  return (
    <section id="services" className="py-20">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">My Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              className="bg-zinc-800 p-6 rounded-lg shadow-lg cursor-pointer"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{
                scale: 1.05,
                rotateX: 5,
                rotateY: 5,
                boxShadow: "0px 10px 20px rgba(0, 0, 0, 0.4)",
                transition: { duration: 0.3 }
              }}
              onClick={() => setSelectedService(index)}
            >
              <h3 className="text-2xl font-bold mb-4">{service.title}</h3>
              <p className="text-zinc-400">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
      <Popup
        isOpen={selectedService !== null}
        onClose={() => setSelectedService(null)}
        variant="services"
      >
        {selectedService !== null && (
          <div className="text-white">
            <h3 className="text-2xl font-bold mb-4">{services[selectedService].title}</h3>
            <p className="mb-4">{services[selectedService].description}</p>
            <p>{services[selectedService].details}</p>
          </div>
        )}
      </Popup>
    </section>
  );
}

