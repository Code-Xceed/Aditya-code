import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Popup from './Popup';

const timelineData = [
  { 
    year: '2023', 
    event: 'Led development of major enterprise application',
    details: 'Spearheaded a team of 10 developers to create a cutting-edge enterprise application using React, Node.js, and GraphQL. The application improved company-wide productivity by 35%.'
  },
  { 
    year: '2022', 
    event: 'Senior Developer at Tech Corp',
    details: 'Promoted to Senior Developer role. Mentored junior developers and implemented best practices that reduced bug reports by 40%.'
  },
  { 
    year: '2021', 
    event: 'Launched successful freelance career',
    details: 'Started freelancing full-time. Completed over 20 projects for clients across various industries, maintaining a 100% satisfaction rate.'
  },
];

export default function Timeline() {
  const [selectedItem, setSelectedItem] = useState<number | null>(null);

  return (
    <section id="timeline" className="py-20 bg-zinc-900">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-12">My Journey</h2>
        <div className="relative">
          <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-emerald-400"></div>
          {timelineData.map((item, index) => (
            <motion.div
              key={index}
              className="relative mb-12 cursor-pointer"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              onClick={() => setSelectedItem(index)}
            >
              <div className={`flex items-center ${index % 2 === 0 ? 'flex-row-reverse' : ''}`}>
                <div className="w-1/2"></div>
                <div className="w-6 h-6 bg-emerald-400 rounded-full absolute left-1/2 transform -translate-x-1/2 z-10"></div>
                <motion.div
                  className="w-1/2 p-4 bg-zinc-800 rounded-lg shadow-lg"
                  whileHover={{
                    scale: 1.05,
                    rotateX: 5,
                    rotateY: 5,
                    boxShadow: "0px 10px 20px rgba(0, 0, 0, 0.4)",
                    transition: { duration: 0.3 }
                  }}
                >
                  <h3 className="text-xl font-bold mb-2">{item.year}</h3>
                  <p className="text-zinc-400">{item.event}</p>
                </motion.div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
      <Popup
        isOpen={selectedItem !== null}
        onClose={() => setSelectedItem(null)}
        variant="timeline"
      >
        {selectedItem !== null && (
          <div className="text-white">
            <h3 className="text-2xl font-bold mb-4">{timelineData[selectedItem].year}</h3>
            <p className="mb-4">{timelineData[selectedItem].event}</p>
            <p>{timelineData[selectedItem].details}</p>
          </div>
        )}
      </Popup>
    </section>
  );
}

