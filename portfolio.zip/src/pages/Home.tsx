import React from 'react';
import Hero from '../components/Hero';
import Timeline from '../components/Timeline';
import Services from '../components/Services';
import Contact from '../components/Contact';

export default function Home() {
  return (
    <>
      <Hero />
      <Timeline />
      <Services />
      <Contact />
    </>
  );
}

